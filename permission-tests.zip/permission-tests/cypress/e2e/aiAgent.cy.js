describe("AI Agent Chat", () => {
  beforeEach(() => {
    cy.visit("https://ask.permission.io/ai");
  });

  it("Page loads with chat interface", () => {
    cy.contains("Ask Permission").should("be.visible");
    cy.get("textarea").should("exist").and("have.attr", "placeholder");
    cy.get("button").contains("Send").should("exist");
  });

  it("Send and receive a message", () => {
    cy.get("textarea").type("Hello AI!");
    cy.get("button").contains("Send").click();
    cy.contains("Hello AI!").should("be.visible");
    cy.get(".message").should("have.length.at.least", 1);
  });

  it("Messages persist during session", () => {
    cy.get("textarea").type("Test persistence");
    cy.get("button").contains("Send").click();
    cy.reload();
    cy.contains("Test persistence").should("be.visible");
  });
});
