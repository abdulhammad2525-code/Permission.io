describe("Form & UI Checks", () => {
  beforeEach(() => {
    cy.visit("/");
  });

  it("Required fields show validation", () => {
    cy.get("form").within(() => {
      cy.get('button[type="submit"]').click();
    });
    cy.contains("This field is required").should("be.visible");
  });

  it("Form submits with valid input", () => {
    cy.get('input[name="name"]').type("John Doe");
    cy.get('input[name="email"]').type("john@example.com");
    cy.get("form").submit();
    cy.contains("Form submitted successfully").should("be.visible");
  });

  it("All buttons and links work", () => {
    cy.get("a").each(($el) => {
      expect($el.attr("href")).to.not.be.empty;
    });
  });

  it("Popups or modals display correctly", () => {
    cy.contains("Open Modal").click();
    cy.get(".modal").should("be.visible");
  });
});
