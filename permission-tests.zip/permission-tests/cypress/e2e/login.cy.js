describe("Login Feature", () => {
  beforeEach(() => {
    cy.visit("/");
    cy.contains("Login").click(); // Adjust if login button is named differently
  });

  it("Successful login with valid credentials", () => {
    cy.get('input[name="email"]').type("validuser@example.com");
    cy.get('input[name="password"]').type("ValidPassword123");

    // For ReCaptcha, pause for manual click
    cy.pause(); // <-- Manual intervention (Option 1)

    cy.get('button[type="submit"]').click();
    cy.url().should("include", "/dashboard");
  });

  it("Fail login with wrong credentials", () => {
    cy.get('input[name="email"]').type("wrong@example.com");
    cy.get('input[name="password"]').type("WrongPassword");
    cy.get('button[type="submit"]').click();
    cy.contains("Invalid email or password").should("be.visible");
  });

  it("Account lockout after multiple failed attempts", () => {
    for (let i = 0; i < 5; i++) {
      cy.get('input[name="email"]').clear().type("validuser@example.com");
      cy.get('input[name="password"]').clear().type("WrongPassword");
      cy.get('button[type="submit"]').click();
    }
    cy.contains("Your account is locked").should("be.visible");
  });
});
